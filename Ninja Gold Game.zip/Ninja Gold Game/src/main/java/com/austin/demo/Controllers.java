package com.austin.demo;

import jakarta.servlet.http.HttpSession;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.stereotype.Controller;

@Controller
public class Controllers {

    @RequestMapping("/")
    public String index(HttpSession session, Model model) {
        if (session.getAttribute("gold") == null) {
            session.setAttribute("gold", 0);
            session.setAttribute("activities", new ArrayList<String>());
        }

        model.addAttribute("gold", session.getAttribute("gold"));
        model.addAttribute("activities", session.getAttribute("activities"));

        return "index.jsp";
    }

    @RequestMapping(value = "/process_money", method = RequestMethod.POST)
    public String processMoney(@RequestParam(value = "building") String building, HttpSession session) {

        Random rand = new Random();
        int gold = 0;
        String action = "";
        List<String> activities = (List<String>) session.getAttribute("activities");

        switch (building) {

            case "farm":
                gold = rand.nextInt(11) + 10; // 10-20
                action = "Earned " + gold + " gold from the farm!";
                break;
            case "cave":
                gold = rand.nextInt(6) + 5; // 5-10
                action = "Earned " + gold + " gold from the cave!";
                break;
            case "house":
                gold = rand.nextInt(4) + 2; // 2-5
                action = "Earned " + gold + " gold from the house!";
                break;
            case "quest":
                gold = rand.nextInt(101) - 50; // -50 to 50
                if (gold >= 0) {
                    action = "Earned " + gold + " gold from the quest!";
                } else {
                    action = "Lost " + (-gold) + " gold from the quest!";
                }
                break;
            case "spa":
                gold = -(rand.nextInt(16) + 5); // -5 to -20
                action = "Lost " + (-gold) + " gold at the spa!";
                break;
        }

        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss a");
        String timestamp = dateFormat.format(new Date());

        action = "You entered a " + building + " and " + (gold >= 0 ? "earned " : "lost ") + Math.abs(gold) + " gold. " + timestamp;

        int currentGold = (int) session.getAttribute("gold");
        currentGold += gold;
        session.setAttribute("gold", currentGold);

        activities.add(0, action); // Add the new action to the top
        session.setAttribute("activities", activities);

        if (currentGold < -50) {
            return "redirect:/prison";
        }

        return "redirect:/";
    }

    @RequestMapping("/reset")
    public String reset(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @RequestMapping("/prison")
    public String prison() {
        return "prison.jsp";
    }
}
